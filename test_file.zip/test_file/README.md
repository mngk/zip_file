# ansible_Bash_Playbook

## How To Use

- Create Jenkins A job
- Provide a Job Name jenkins Job Type = Pipeline then OK
- Select as IMAGE Option Below
![pipeline job](https://user-images.githubusercontent.com/22466745/31443707-d912388c-aeb7-11e7-9413-2d50027774f0.PNG)
- REPOSITORY URL - https://github.com/harishchanderdalal/ansible_Bash_Playbook.git
- same and RUN JOB


## How Create Your OWN
- Use this URL and clone in you GITHUB
- Change Your pipeline job or change REPOSITRY URL your GITHUB 
- So when you push you change you job will work

NOTE - Configure Job Build Triggers > Build periodically 
```
* * * * *
```
Save and wait after next Commit
